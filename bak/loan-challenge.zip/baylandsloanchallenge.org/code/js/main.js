function log( message ) {
	if ( window.console ) {
		console.log( message );
	}
}

$(document).ready(function(){

	$("#calculate").click(function(){
		var credit_amount=$("#credit-amount").val(),
			credit_rate=$("#credit-rate").val(),
			auto_amount=$("#auto-amount").val(),
			auto_rate=$("#auto-rate").val(),
			auto_term=$("#auto-term").val(),
			personal_amount=$("#personal-amount").val(),
			personal_rate=$("#personal-rate").val(),
			personal_term=$("#personal-term").val();

		$.get( "calculate.php?"
			+"credit_amount="+credit_amount
			+"&credit_rate="+credit_rate
			+"&auto_amount="+auto_amount
			+"&auto_rate="+auto_rate
			+"&auto_term="+auto_term
			+"&personal_amount="+personal_amount
			+"&personal_rate="+personal_rate
			+"&personal_term="+personal_term, function(response){
			
			// parse response from calculate.php to a JSON object
			response=$.parseJSON( response );

			if ( response.total>0 ) {

				// set the results table title and subtitle
				$("#savings-title").html( response.savings_title );
				$("#savings-message").html( response.savings_message );
				
				if ( response.savings.credit.savings>0 ) {
					$("#savings-credit span").html( response.savings.credit.savings_formatted );
					$("#savings-credit").slideDown( 500 );
				}
				if ( response.savings.auto.savings>0 ) {
					$("#savings-auto span").html( response.savings.auto.savings_formatted );
					$("#savings-auto").slideDown( 500 );
				}
				if ( response.savings.personal.savings>0 ) {
					$("#savings-personal span").html( response.savings.personal.savings_formatted );
					$("#savings-personal").slideDown( 500 );
				}

				// display the rows in the results table
				$("#savings-total").html( response.total_formatted );

				$("#header-content").html("<h1>Congratulations!</h1><h2>Here's your ticket to extra savings!</h2>");
				
				// hide calculators and display results now that they're populated.
				$("#calculators").slideUp( 750 );
				$("#results").slideDown( 750 );

				// scroll to top of the calculators div
				$("body").animate({
				   scrollTop: $("#calculators").offset().top
				}, 750 );

				$("p.hidden.error:visible").slideUp( 300 );

				clearInterval( testimonial_interval );
			
			} else {
				$("p.hidden.error:hidden").slideDown( 300 );
			}

		});
	});

	$("#go-back").click(function(){
		$("#savings-personal:visible, #savings-auto:visible, #savings-credit:visible").slideUp( 500 );
		$("#results").slideUp( 500 );
		$("#calculators").slideDown( 500 );
		$("#header-content").html("<h2>Just tell us a little about one or more of your current loans below and receive your ticket to savings!</h2>");
		$("body").animate({
		   scrollTop: $(".main-content").offset().top
		}, 500 );
	});

	$(".rel-link").click(function(){
		if ( $(this).attr( "rel" ).length>0 ) {
			location.href=$(this).attr("rel");
		}
	});

});