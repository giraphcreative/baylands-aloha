<?php


/**************************************************************
   
    RATES
    We'll set the Baylands rate based on the term they
    provide.
	
 **************************************************************/

$rates=array(
	"auto" => array(
		"12m"	=>	1.49,
		"24m"	=>	1.49,
		"36m"	=>	1.99,
		"48m"	=>	1.99,
		"60m"	=>	2.25,
		"72m"	=>	2.5,
		"84m"	=>	3	
	),
	"personal" => 8.49,
	"credit" => 8.90
);




/**************************************************************
   
    REQUEST HELPER:
    Just to quickly grab request vars and set a default
    value if they're not set.
	
 **************************************************************/
function request( $param, $default="" ) {
	return ( isset( $_REQUEST[$param] ) ? $_REQUEST[$param] : ( !empty( $default ) ? $default : "" ) );
}





/**************************************************************
   
    LOAN FUNCTIONS
	
 **************************************************************/
function get_loan_info( $amount=0, $rate=0, $term=0 ) {
	if ( $amount*$rate*$term > 0 ) {
		$mrate=$rate/1200; //monthly interest rate
		$pmnt=$amount*($mrate/(1-pow(1+$mrate,-$term))); //monthly payment
		$tpmnt=$pmnt * $term; //total amount paid at end of loan
		$tint=$tpmnt-$amount; //total amount of interest paid at end of loan
		return (object) array(
			"total_payments" => $tpmnt,
			"total_interest" => $tint,
			"number_payments" => $term,
			"monthly_payment" => $pmnt 
		);
	} else {
		return false;
	}
}


// Savings calculation
function get_savings( $amount=0, $cu_rate=0, $bank_rate=0, $term="12m" ) {
	$cu_loan_info=get_loan_info( $amount, $cu_rate, $term );
	$bank_loan_info=get_loan_info( $amount, $bank_rate, $term );
	$savings=$bank_loan_info->total_interest - $cu_loan_info->total_interest;
	$savings=( $savings>0 ? $savings : 0 );
	return (object) array(
		"savings"=>$savings,
		"savings_formatted"=>"$".( is_int( $savings ) ? $savings : number_format( $savings, 2, ".", "," ) ),
		"cu_loan_info"=>$cu_loan_info,
		"bank_loan_info"=>$bank_loan_info,
	);
}


// Format number as a dollar amount
function format_number( $number ) {
	return number_format( $number, 2, ".", "," );
}




/**************************************************************
   
    HANDLE CALCULATION REQUESTS
	
 **************************************************************/

$response=new stdClass;
$response->request=$_REQUEST;
$response->rates=$rates;


// loop through all the rate types and get request variables.
$savings=array();
foreach ( $rates as $rate_type=>$cu_rate ) {
	$amount=preg_replace("/[^0-9\.]/", "", request( $rate_type."_amount" ) );
	$rate=preg_replace("/[^0-9\.]/", "", request( $rate_type."_rate" ) );
	$term=request( $rate_type."_term", "12" );
	if ( $rate_type=="auto" ) {
		$cu_rate=$cu_rate[$term];
	}
	
	$savings[$rate_type]=get_savings( $amount, $cu_rate, $rate, $term );   //make an instance of amort and set the numbers;
}


$response->savings=$savings;
$response->total=$savings["credit"]->savings+
				$savings["auto"]->savings+
				$savings["personal"]->savings;


$response->total_formatted="$".( is_int( $response->total ) ? $response->total : number_format( $response->total, 2, ".", "," ) );

// set title and message based on savings.
$response->savings_message="You could save up to " . $response->total_formatted[720] . "!";


// return response by printing it to the page
print json_encode( $response );


?>
