function api_call( action, params, callback ) {
	$.post( "/calculate.php?action="+action+"&"+params, function(data){
		callback(data);
	});
}

function calculate(){
	var balance=$("#balance").val(),
		rate=$("#rate").val(),
		term=$("#term").val();
	$.post( "/calculate.php?balance="+balance+"&rate="+rate+"&term="+term, function(data){
		if ( data!=="Error" ) {
			var loans=$.parseJSON( data );
			//console.log( loans );
			$("#savings").html( loans.savings );
			$("#cu_payment").html( "$"+loans.cu_loan_info.monthly_payment.toFixed(2) );
			$("#cu_interest").html( "$"+loans.cu_loan_info.total_interest.toFixed(2) );
			$("#bank_payment").html( "$"+loans.bank_loan_info.monthly_payment.toFixed(2) );
			$("#bank_interest").html( "$"+loans.bank_loan_info.total_interest.toFixed(2) );
			$("#tool").slideUp( 1000 );
			$("#results").slideDown( 1000 );
			$("#banner h1").html("Touchdown! You score!");
		}
	});
};

$(document).ready(function(){
	
	$("#calculate").click( calculate );

	$("input").keypress(function(e) {
	    if(e.which == 13) {
	        calculate();
	    }
	});

	$(".numbers-only").keyup(function(){
		if ( $(this).val().match(/[^0-9\.]/) ) {
			$(this).val( $(this).val().replace(/[^0-9\.]+/g, '') );
		}
	});

	$("#back").click(function(){
		$("#results").slideUp( 1000 );
		$("#tool").slideDown( 1000 );
		$("#banner h1").html("We'll beat your auto loan payment!");
	});

	$("#apply").click(function(){
		location.href="http://www.baylandsfcu.org/asp/loan.asp";
	});

	$("#brand-footer .wrapper").click(function(){
		location.href="http://www.baylandsfcu.org/ASP/home.asp";
	});

});