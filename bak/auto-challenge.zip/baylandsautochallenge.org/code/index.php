<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Auto Loan Challenge | Baylands FCU</title>
	<meta name="description" content="Baylands FCU: Auto Loan Challenge">
	<meta name="author" content="Baylands FCU">	
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="stylesheet" href="/css/main.css">
	<!--[if lt IE 9]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>
<body>
	<div id="header">
		<div class="wrapper">

		</div>
	</div>
	<div id="banner">
		<div class="wrapper">
			<h1>We'll beat your auto loan payment!</h1>
		</div>
	</div>
	<div id="tool">
		<div class="wrapper">
			<h2>Just tell us a little about your current auto loan below and your home team credit union will pass you the savings.</h2>
			<div id="box">
				<div class="half">
					<p>Your current auto loan balance<br />
						<input type="text" id="balance" value="" class="numbers-only" /></p>
					<p>Your current rate<br />
						<input type="text" id="rate" value="" class="numbers-only" /></p>
				</div>
				<div class="half">
					<p>Your current term<br />
						<select id="term">
							<option value="12">12 months</option>
							<option value="24">24 months</option>
							<option value="36">36 months</option>
							<option value="48">48 months</option>
							<option value="60">60 months</option>
							<option value="72">72 months</option>
							<option value="84">84 months</option>
						</select></p>
					<p><button id="calculate">Game On!<br />
						<span>Click here for savings.</span></button></p>
				</div>
				<div class="clear"></div>
			</div>
			<div id="rates"></div>
		</div>
	</div>
	<div id="results" class="hidden">
		<div class="wrapper">
			<h1>Victory is yours!</h1>
			<h1>You can save up to <span id="savings"></span> in interest!</h1>
			<table cellspacing="2" cellpadding="0" border="0">
				<tr>
					<th>&nbsp;</th>
					<th>Monthly Payment</th>
					<th>Total Interest</th>
				</tr>
				<tr class="cu">
					<td nowrap><strong>Baylands</strong></td>
					<td id="cu_payment"></td>
					<td id="cu_interest"></td>
				</tr>
				<tr class="bank">
					<td nowrap><strong>Bank/Other</strong></td>
					<td id="bank_payment"></td>
					<td id="bank_interest"></td>
				</tr>
			</table>
			<div class="half">
				<button id="back"><span>Go Back</span><br />
					Let's play<br /> again!</button>
			</div>
			<div class="half">
				<button id="apply">I’m ready<br />
					to save. <br />
					<span>Apply now.</span></button>
			</div>
			<div class="clear"></div>
		</div>
	</div>
	<div id="brand-footer"><div class="wrapper"></div></div>
	<div id="footer">
		<div class="wrapper">
			<p>*APR = Annual Percentage Rate. Credit restrictions apply. Rates based on creditworthiness, 
				term and other factors. Rate and promotion are subject to change at any time. 
				See credit union for details. Loans financed with the credit union must finance an 
				additional minimum of $10,000.00 to qualify for refinancing. Calculator based on best 
				scenario. Your savings may be different depending on your unique situation and 
				creditworthiness. This credit union is insured by the National Credit Union Administration.</p>
			<p class="copyright">Copyright &copy; <?php print date( "Y" ); ?> Baylands FCU. All Rights Reserved.</p>
		</div>
	</div>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="/js/main.js"></script>
</body>
</html>